export interface User {
  id: number
  email: string
  first_name: string
  last_name: string
  role: "admin" | "teacher" | "student"
  created_at: string
}

export interface Exam {
  id: number
  title: string
  description: string
  created_by: number
  duration_minutes: number
  total_questions: number
  passing_score: number
  is_published: boolean
  start_date: string
  end_date: string
  created_at: string
}

export interface Question {
  id: number
  exam_id: number
  question_text: string
  question_type: "mcq" | "essay" | "short_answer"
  marks: number
  display_order: number
}

export interface Option {
  id: number
  question_id: number
  option_text: string
  is_correct: boolean
  display_order: number
}

export interface Submission {
  id: number
  exam_id: number
  student_id: number
  started_at: string
  submitted_at: string | null
  total_score: number
  max_score: number
  percentage: number
  is_passed: boolean
  status: "in_progress" | "submitted" | "graded"
}

export interface Answer {
  id: number
  submission_id: number
  question_id: number
  option_id: number | null
  text_answer: string | null
  score_obtained: number
  is_correct: boolean
}

export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
  message?: string
}
