import { neon } from "@neondatabase/serverless"

let sql: ReturnType<typeof neon> | null = null

export function getDb() {
  if (!sql) {
    if (!process.env.DATABASE_URL) {
      throw new Error("DATABASE_URL environment variable is required")
    }
    sql = neon(process.env.DATABASE_URL)
  }
  return sql
}

export async function query(text: string, params?: any[]) {
  const sql = getDb()
  try {
    const result = await sql(text, params)
    return result
  } catch (error) {
    console.error("Database query error:", error)
    throw error
  }
}
