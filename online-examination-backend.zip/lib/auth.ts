import bcrypt from "bcryptjs"
import { query } from "./db"
import type { User } from "./types"

export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(10)
  return bcrypt.hash(password, salt)
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash)
}

export async function getUserByEmail(email: string): Promise<User | null> {
  const result = await query("SELECT * FROM users WHERE email = $1", [email])
  return result.length > 0 ? result[0] : null
}

export async function getUserById(id: number): Promise<User | null> {
  const result = await query("SELECT * FROM users WHERE id = $1", [id])
  return result.length > 0 ? result[0] : null
}

export async function createUser(
  email: string,
  password: string,
  firstName: string,
  lastName: string,
  role: "admin" | "teacher" | "student" = "student",
): Promise<User> {
  const passwordHash = await hashPassword(password)
  const result = await query(
    "INSERT INTO users (email, password_hash, first_name, last_name, role) VALUES ($1, $2, $3, $4, $5) RETURNING id, email, first_name, last_name, role, created_at",
    [email, passwordHash, firstName, lastName, role],
  )
  return result[0]
}

export async function verifyUser(email: string, password: string): Promise<User | null> {
  const result = await query("SELECT * FROM users WHERE email = $1", [email])

  if (result.length === 0) {
    return null
  }

  const user = result[0]
  const passwordValid = await verifyPassword(password, user.password_hash)

  if (!passwordValid) {
    return null
  }

  return {
    id: user.id,
    email: user.email,
    first_name: user.first_name,
    last_name: user.last_name,
    role: user.role,
    created_at: user.created_at,
  }
}
