export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen bg-background">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-4">Online Examination Backend</h1>
        <p className="text-muted-foreground mb-8">API Documentation</p>

        <div className="bg-card rounded-lg p-8 shadow-lg max-w-2xl">
          <h2 className="text-2xl font-semibold mb-6">Available Endpoints</h2>

          <div className="text-left space-y-4">
            <div>
              <h3 className="font-semibold text-primary">Authentication</h3>
              <p className="text-sm text-muted-foreground">POST /api/auth/register</p>
              <p className="text-sm text-muted-foreground">POST /api/auth/login</p>
            </div>

            <div>
              <h3 className="font-semibold text-primary">Exams</h3>
              <p className="text-sm text-muted-foreground">GET /api/exams</p>
              <p className="text-sm text-muted-foreground">POST /api/exams</p>
              <p className="text-sm text-muted-foreground">GET /api/exams/[id]</p>
              <p className="text-sm text-muted-foreground">PUT /api/exams/[id]</p>
            </div>

            <div>
              <h3 className="font-semibold text-primary">Questions</h3>
              <p className="text-sm text-muted-foreground">GET /api/questions?examId=[id]</p>
              <p className="text-sm text-muted-foreground">POST /api/questions</p>
            </div>

            <div>
              <h3 className="font-semibold text-primary">Options</h3>
              <p className="text-sm text-muted-foreground">GET /api/options?questionId=[id]</p>
              <p className="text-sm text-muted-foreground">POST /api/options</p>
            </div>

            <div>
              <h3 className="font-semibold text-primary">Submissions</h3>
              <p className="text-sm text-muted-foreground">GET /api/submissions</p>
              <p className="text-sm text-muted-foreground">POST /api/submissions</p>
              <p className="text-sm text-muted-foreground">POST /api/submissions/[id]/submit</p>
            </div>

            <div>
              <h3 className="font-semibold text-primary">Results</h3>
              <p className="text-sm text-muted-foreground">GET /api/results?submissionId=[id]</p>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
