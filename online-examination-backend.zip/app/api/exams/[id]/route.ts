import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/db"
import type { ApiResponse, Exam } from "@/lib/types"

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const result = await query("SELECT * FROM exams WHERE id = $1", [Number.parseInt(id)])

    if (result.length === 0) {
      return NextResponse.json({ success: false, error: "Exam not found" } as ApiResponse<null>, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      data: result[0],
    } as ApiResponse<Exam>)
  } catch (error) {
    console.error("Error fetching exam:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch exam" } as ApiResponse<null>, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await request.json()
    const { title, description, durationMinutes, passingScore, isPublished } = body

    const result = await query(
      `UPDATE exams 
       SET title = COALESCE($1, title), 
           description = COALESCE($2, description),
           duration_minutes = COALESCE($3, duration_minutes),
           passing_score = COALESCE($4, passing_score),
           is_published = COALESCE($5, is_published),
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $6
       RETURNING *`,
      [title, description, durationMinutes, passingScore, isPublished, Number.parseInt(id)],
    )

    if (result.length === 0) {
      return NextResponse.json({ success: false, error: "Exam not found" } as ApiResponse<null>, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      data: result[0],
      message: "Exam updated successfully",
    } as ApiResponse<Exam>)
  } catch (error) {
    console.error("Error updating exam:", error)
    return NextResponse.json({ success: false, error: "Failed to update exam" } as ApiResponse<null>, { status: 500 })
  }
}
