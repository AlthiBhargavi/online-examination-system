import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/db"
import type { ApiResponse, Exam } from "@/lib/types"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const published = searchParams.get("published") === "true"

    let sql = "SELECT * FROM exams WHERE is_published = $1 ORDER BY created_at DESC"
    const params: any[] = [published]

    if (!published) {
      sql = "SELECT * FROM exams ORDER BY created_at DESC"
      params.pop()
    }

    const exams = await query(sql, params.length > 0 ? params : undefined)

    return NextResponse.json({
      success: true,
      data: exams,
    } as ApiResponse<Exam[]>)
  } catch (error) {
    console.error("Error fetching exams:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch exams" } as ApiResponse<null>, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, description, createdBy, durationMinutes, totalQuestions, passingScore } = body

    if (!title || !createdBy || !durationMinutes) {
      return NextResponse.json({ success: false, error: "Missing required fields" } as ApiResponse<null>, {
        status: 400,
      })
    }

    const result = await query(
      `INSERT INTO exams (title, description, created_by, duration_minutes, total_questions, passing_score)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [title, description, createdBy, durationMinutes, totalQuestions || 0, passingScore || 50],
    )

    return NextResponse.json(
      { success: true, data: result[0], message: "Exam created successfully" } as ApiResponse<Exam>,
      { status: 201 },
    )
  } catch (error) {
    console.error("Error creating exam:", error)
    return NextResponse.json({ success: false, error: "Failed to create exam" } as ApiResponse<null>, { status: 500 })
  }
}
