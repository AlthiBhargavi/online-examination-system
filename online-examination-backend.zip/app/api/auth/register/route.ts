import { type NextRequest, NextResponse } from "next/server"
import { createUser, getUserByEmail } from "@/lib/auth"
import type { ApiResponse, User } from "@/lib/types"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password, firstName, lastName, role } = body

    if (!email || !password || !firstName || !lastName) {
      return NextResponse.json({ success: false, error: "Missing required fields" } as ApiResponse<null>, {
        status: 400,
      })
    }

    const existingUser = await getUserByEmail(email)
    if (existingUser) {
      return NextResponse.json({ success: false, error: "User already exists" } as ApiResponse<null>, { status: 409 })
    }

    const user = await createUser(email, password, firstName, lastName, role || "student")

    return NextResponse.json(
      {
        success: true,
        data: user,
        message: "User registered successfully",
      } as ApiResponse<User>,
      { status: 201 },
    )
  } catch (error) {
    console.error("Registration error:", error)
    return NextResponse.json({ success: false, error: "Internal server error" } as ApiResponse<null>, { status: 500 })
  }
}
