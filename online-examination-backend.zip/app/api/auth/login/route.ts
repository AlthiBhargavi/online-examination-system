import { type NextRequest, NextResponse } from "next/server"
import { verifyUser } from "@/lib/auth"
import type { ApiResponse, User } from "@/lib/types"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password } = body

    if (!email || !password) {
      return NextResponse.json({ success: false, error: "Email and password required" } as ApiResponse<null>, {
        status: 400,
      })
    }

    const user = await verifyUser(email, password)
    if (!user) {
      return NextResponse.json({ success: false, error: "Invalid credentials" } as ApiResponse<null>, { status: 401 })
    }

    return NextResponse.json(
      {
        success: true,
        data: user,
        message: "Login successful",
      } as ApiResponse<User>,
      { status: 200 },
    )
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ success: false, error: "Internal server error" } as ApiResponse<null>, { status: 500 })
  }
}
