import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/db"
import type { ApiResponse, Question } from "@/lib/types"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const examId = searchParams.get("examId")

    if (!examId) {
      return NextResponse.json({ success: false, error: "examId parameter required" } as ApiResponse<null>, {
        status: 400,
      })
    }

    const result = await query("SELECT * FROM questions WHERE exam_id = $1 ORDER BY display_order ASC", [
      Number.parseInt(examId),
    ])

    return NextResponse.json({
      success: true,
      data: result,
    } as ApiResponse<Question[]>)
  } catch (error) {
    console.error("Error fetching questions:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch questions" } as ApiResponse<null>, {
      status: 500,
    })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { examId, questionText, questionType, marks, displayOrder } = body

    if (!examId || !questionText) {
      return NextResponse.json({ success: false, error: "Missing required fields" } as ApiResponse<null>, {
        status: 400,
      })
    }

    const result = await query(
      `INSERT INTO questions (exam_id, question_text, question_type, marks, display_order)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [examId, questionText, questionType || "mcq", marks || 1, displayOrder || 0],
    )

    return NextResponse.json({ success: true, data: result[0], message: "Question created" } as ApiResponse<Question>, {
      status: 201,
    })
  } catch (error) {
    console.error("Error creating question:", error)
    return NextResponse.json({ success: false, error: "Failed to create question" } as ApiResponse<null>, {
      status: 500,
    })
  }
}
