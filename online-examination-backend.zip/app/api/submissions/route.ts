import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/db"
import type { ApiResponse, Submission } from "@/lib/types"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const examId = searchParams.get("examId")
    const studentId = searchParams.get("studentId")

    let sql = "SELECT * FROM submissions WHERE 1=1"
    const params: any[] = []

    if (examId) {
      sql += " AND exam_id = $" + (params.length + 1)
      params.push(Number.parseInt(examId))
    }

    if (studentId) {
      sql += " AND student_id = $" + (params.length + 1)
      params.push(Number.parseInt(studentId))
    }

    sql += " ORDER BY created_at DESC"

    const result = await query(sql, params)

    return NextResponse.json({
      success: true,
      data: result,
    } as ApiResponse<Submission[]>)
  } catch (error) {
    console.error("Error fetching submissions:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch submissions" } as ApiResponse<null>, {
      status: 500,
    })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { examId, studentId } = body

    if (!examId || !studentId) {
      return NextResponse.json({ success: false, error: "Missing required fields" } as ApiResponse<null>, {
        status: 400,
      })
    }

    const result = await query(
      `INSERT INTO submissions (exam_id, student_id, status)
       VALUES ($1, $2, 'in_progress')
       RETURNING *`,
      [examId, studentId],
    )

    return NextResponse.json(
      { success: true, data: result[0], message: "Submission started" } as ApiResponse<Submission>,
      { status: 201 },
    )
  } catch (error) {
    console.error("Error creating submission:", error)
    return NextResponse.json({ success: false, error: "Failed to create submission" } as ApiResponse<null>, {
      status: 500,
    })
  }
}
