import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/db"
import type { ApiResponse, Submission } from "@/lib/types"

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await request.json()
    const { answers } = body // Array of { questionId, optionId OR textAnswer }

    if (!answers || !Array.isArray(answers)) {
      return NextResponse.json({ success: false, error: "Invalid answers format" } as ApiResponse<null>, {
        status: 400,
      })
    }

    const submissionId = Number.parseInt(id)

    // Get submission and exam details
    const submissionResult = await query("SELECT * FROM submissions WHERE id = $1", [submissionId])
    if (submissionResult.length === 0) {
      return NextResponse.json({ success: false, error: "Submission not found" } as ApiResponse<null>, { status: 404 })
    }

    const submission = submissionResult[0]
    let totalScore = 0
    let maxScore = 0

    // Process each answer
    for (const answer of answers) {
      const { questionId, optionId, textAnswer } = answer

      // Get question details
      const questionResult = await query("SELECT marks FROM questions WHERE id = $1 AND exam_id = $2", [
        questionId,
        submission.exam_id,
      ])

      if (questionResult.length === 0) continue

      const marks = questionResult[0].marks
      maxScore += marks

      let isCorrect = false
      let scoreObtained = 0

      if (optionId) {
        // MCQ answer - check if correct
        const optionResult = await query("SELECT is_correct FROM options WHERE id = $1", [optionId])
        if (optionResult.length > 0) {
          isCorrect = optionResult[0].is_correct
          scoreObtained = isCorrect ? marks : 0
          totalScore += scoreObtained
        }
      }

      // Store the answer
      await query(
        `INSERT INTO answers (submission_id, question_id, option_id, text_answer, score_obtained, is_correct)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [submissionId, questionId, optionId || null, textAnswer || null, scoreObtained, isCorrect],
      )
    }

    const percentage = maxScore > 0 ? (totalScore / maxScore) * 100 : 0
    const examResult = await query("SELECT passing_score FROM exams WHERE id = $1", [submission.exam_id])
    const passingScore = examResult.length > 0 ? examResult[0].passing_score : 50
    const isPassed = percentage >= passingScore

    // Update submission
    const updatedResult = await query(
      `UPDATE submissions 
       SET submitted_at = CURRENT_TIMESTAMP, 
           total_score = $1, 
           max_score = $2,
           percentage = $3,
           is_passed = $4,
           status = 'submitted'
       WHERE id = $5
       RETURNING *`,
      [totalScore, maxScore, percentage, isPassed, submissionId],
    )

    return NextResponse.json({
      success: true,
      data: updatedResult[0],
      message: "Exam submitted successfully",
    } as ApiResponse<Submission>)
  } catch (error) {
    console.error("Error submitting exam:", error)
    return NextResponse.json({ success: false, error: "Failed to submit exam" } as ApiResponse<null>, { status: 500 })
  }
}
