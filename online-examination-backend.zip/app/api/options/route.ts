import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/db"
import type { ApiResponse } from "@/lib/types"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const questionId = searchParams.get("questionId")

    if (!questionId) {
      return NextResponse.json({ success: false, error: "questionId parameter required" } as ApiResponse<null>, {
        status: 400,
      })
    }

    const result = await query("SELECT * FROM options WHERE question_id = $1 ORDER BY display_order ASC", [
      Number.parseInt(questionId),
    ])

    return NextResponse.json({
      success: true,
      data: result,
    } as ApiResponse<any>)
  } catch (error) {
    console.error("Error fetching options:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch options" } as ApiResponse<null>, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { questionId, optionText, isCorrect, displayOrder } = body

    if (!questionId || !optionText) {
      return NextResponse.json({ success: false, error: "Missing required fields" } as ApiResponse<null>, {
        status: 400,
      })
    }

    const result = await query(
      `INSERT INTO options (question_id, option_text, is_correct, display_order)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [questionId, optionText, isCorrect || false, displayOrder || 0],
    )

    return NextResponse.json({ success: true, data: result[0] } as ApiResponse<any>, { status: 201 })
  } catch (error) {
    console.error("Error creating option:", error)
    return NextResponse.json({ success: false, error: "Failed to create option" } as ApiResponse<null>, { status: 500 })
  }
}
