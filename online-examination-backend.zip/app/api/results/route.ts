import { type NextRequest, NextResponse } from "next/server"
import { query } from "@/lib/db"
import type { ApiResponse } from "@/lib/types"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const submissionId = searchParams.get("submissionId")

    if (!submissionId) {
      return NextResponse.json({ success: false, error: "submissionId parameter required" } as ApiResponse<null>, {
        status: 400,
      })
    }

    // Get submission details
    const submission = await query("SELECT * FROM submissions WHERE id = $1", [Number.parseInt(submissionId)])
    if (submission.length === 0) {
      return NextResponse.json({ success: false, error: "Submission not found" } as ApiResponse<null>, { status: 404 })
    }

    // Get exam details
    const exam = await query("SELECT title, passing_score FROM exams WHERE id = $1", [submission[0].exam_id])

    // Get all answers with question details
    const answers = await query(
      `SELECT a.*, q.question_text, q.marks, q.question_type
       FROM answers a
       JOIN questions q ON a.question_id = q.id
       WHERE a.submission_id = $1
       ORDER BY q.display_order`,
      [Number.parseInt(submissionId)],
    )

    const result = {
      submission: submission[0],
      exam: exam[0],
      answers,
    }

    return NextResponse.json({
      success: true,
      data: result,
    } as ApiResponse<any>)
  } catch (error) {
    console.error("Error fetching results:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch results" } as ApiResponse<null>, { status: 500 })
  }
}
